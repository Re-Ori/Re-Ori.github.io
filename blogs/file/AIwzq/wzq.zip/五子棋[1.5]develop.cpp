#include<bits/stdc++.h>
#include<windows.h>
#include<sys/timeb.h>
#include<conio.h>
#include<fstream>
using namespace std;

const long long INF=1e18;
const int UNDO_MARKER=-1;
const double DEFENSE_WEIGHT=1.5;
	
int puttingPlayer=1,lightx=-1,lighty=-1,step=0,a[64][64];
int W=10,H=10,AInumber=2,MaxDepth=3;
int openAI=true,onlyAI=false,outLastPoint=false,inputMethod=false,outputColor=true;
int showProgress=1;
int allowUndo=1;
int undoPlus=1;
int AITimeLimit=60;
int developerMode=0;

struct StepRecord{
    tuple<int,int,int>step;
    bool canceled;
    int stepNumber;
    time_t timestamp;
    map<pair<int,int>,long long>weights;
    bool forcedDefense;
};
vector<StepRecord>allSteps;
vector<int>history;

bool undoPerformed=false;
int lastAITimeMs=0;
int undoCount1,undoCount2;

const long long WIN_SCORE=1000000;
const long long FOUR_SCORE=50000;
const long long BLOCKED_FOUR_SCORE=10000;
const long long THREE_SCORE=6000;
const long long SLEEP_THREE_SCORE=500;
const long long TWO_SCORE=100;
const long long SLEEP_TWO_SCORE=50;
const long long ONE_SCORE=10;

const string BASE64_CHARS="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-=";
inline char toBase64Char(int x){return BASE64_CHARS[x&63];}
inline int fromBase64Char(char c){
    if(c>='0'&&c<='9')return c-'0';
    if(c>='a'&&c<='z')return c-'a'+10;
    if(c>='A'&&c<='Z')return c-'A'+36;
    if(c=='-')return 62;
    if(c=='=')return 63;
    return 0;
}

int read(int x,int y){return a[x+3][y+3];}
void put(int x,int y,int type){a[x+3][y+3]=type;lightx=x;lighty=y;}

void loadIntConfig(int**configInts,int count,int max_lines=-1){
    ifstream file("config-wzqpro.ini");
    if(!file.is_open())return;
    string line;
    int lines_read=0;
    while(getline(file,line)){
        if(max_lines>=0&&lines_read>=max_lines)break;
        if(lines_read>=count)break;
        try{
            size_t start=line.find_first_not_of(" \t\r\n");
            size_t end=line.find_last_not_of(" \t\r\n");
            if(start==string::npos||end==string::npos)continue;
            string trimmed=line.substr(start,end-start+1);
            if(trimmed.find_first_not_of("-0123456789")!=string::npos)continue;
            *(configInts[lines_read])=stoi(trimmed);
            lines_read++;
        }catch(...){}
    }
    file.close();
}

unsigned long long zobrist[64][64][3];
unsigned long long zobristCurrentHash;

void initZobrist(){
    mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());
    for(int x=1;x<=W;x++){
        for(int y=1;y<=H;y++){
            for(int p=0;p<3;p++){
                zobrist[x][y][p]=rng();
            }
        }
    }
}

void updateHash(int x,int y,int oldPlayer,int newPlayer){
    if(oldPlayer!=0)zobristCurrentHash^=zobrist[x][y][oldPlayer];
    if(newPlayer!=0)zobristCurrentHash^=zobrist[x][y][newPlayer];
}

unsigned long long computeBoardHash(){
    unsigned long long h=0;
    for(int y=1;y<=H;y++){
        for(int x=1;x<=W;x++){
            int p=read(x,y);
            if(p!=0)h^=zobrist[x][y][p];
        }
    }
    return h;
}

struct TTEntry{
    unsigned long long hash;
    int depth;
    long long score;
    int bestX,bestY;
    int flag;
};
const int TT_SIZE=1<<20;
TTEntry transpositionTable[TT_SIZE];

void storeTT(unsigned long long hash,int depth,long long score,int bestX,int bestY,int flag){
    int idx=hash&(TT_SIZE-1);
    if(depth>transpositionTable[idx].depth){
        transpositionTable[idx]={hash,depth,score,bestX,bestY,flag};
    }
}

bool probeTT(unsigned long long hash,int depth,long long&score,int&bestX,int&bestY,int&flag,long long alpha,long long beta){
    int idx=hash&(TT_SIZE-1);
    TTEntry&entry=transpositionTable[idx];
    if(entry.hash!=hash)return false;
    if(entry.depth<depth)return false;
    bestX=entry.bestX;
    bestY=entry.bestY;
    if(entry.flag==0){
        score=entry.score;
        return true;
    }else if(entry.flag==1&&entry.score>=beta){
        score=entry.score;
        return true;
    }else if(entry.flag==2&&entry.score<=alpha){
        return false;
    }
    return false;
}

long long historyScore[64][64];

void updateHistory(int x,int y,int depth){
    historyScore[x][y]+=depth*depth;
}

pair<int,int>killerMoves[64][2];

void updateKiller(int x,int y,int depth){
    if(killerMoves[depth][0].first==-1){
        killerMoves[depth][0]={x,y};
    }else if(killerMoves[depth][1].first==-1){
        killerMoves[depth][1]={x,y};
    }else{
        killerMoves[depth][1]={x,y};
    }
}

bool isKiller(int x,int y,int depth){
    return (killerMoves[depth][0].first==x&&killerMoves[depth][0].second==y)||
           (killerMoves[depth][1].first==x&&killerMoves[depth][1].second==y);
}

tuple<int,bool,bool>countDirection(int x,int y,int player,int dx,int dy){
    int cnt=1;
    bool lb=false,rb=false;
    int nx=x-dx,ny=y-dy;
    while(nx>=1&&nx<=W&&ny>=1&&ny<=H){
        if(read(nx,ny)==player){cnt++;nx-=dx;ny-=dy;}
        else{lb=(read(nx,ny)!=0);break;}
    }
    if(nx<1||nx>W||ny<1||ny>H)lb=true;
    nx=x+dx;ny=y+dy;
    while(nx>=1&&nx<=W&&ny>=1&&ny<=H){
        if(read(nx,ny)==player){cnt++;nx+=dx;ny+=dy;}
        else{rb=(read(nx,ny)!=0);break;}
    }
    if(nx<1||nx>W||ny<1||ny>H)rb=true;
    return make_tuple(cnt,lb,rb);
}

long long getPatternScore(int cnt,bool lb,bool rb){
    if(cnt>=5)return WIN_SCORE;
    if(cnt==4)return (!lb&&!rb)?FOUR_SCORE:((!lb||!rb)?BLOCKED_FOUR_SCORE:0);
    if(cnt==3)return (!lb&&!rb)?THREE_SCORE:((!lb||!rb)?SLEEP_THREE_SCORE:0);
    if(cnt==2)return (!lb&&!rb)?TWO_SCORE:((!lb||!rb)?SLEEP_TWO_SCORE:0);
    if(cnt==1)return (!lb&&!rb)?ONE_SCORE:0;
    return 0;
}

long long evaluatePoint(int x,int y,int player){
    if(read(x,y)&&read(x,y)!=player)return 0;
    int dx[4]={1,0,1,1},dy[4]={0,1,1,-1};
    long long score=0;
    for(int d=0;d<4;d++){
        int cnt;bool lb,rb;
        tie(cnt,lb,rb)=countDirection(x,y,player,dx[d],dy[d]);
        score+=getPatternScore(cnt,lb,rb);
    }
    return score;
}

long long getSegmentScore(int len,int blockCount){
    if(len>=5)return WIN_SCORE;
    if(len==4){
        if(blockCount==0)return FOUR_SCORE;
        else if(blockCount==1)return BLOCKED_FOUR_SCORE;
        else return 0;
    }
    if(len==3){
        if(blockCount==0)return THREE_SCORE;
        else if(blockCount==1)return SLEEP_THREE_SCORE;
        else return 0;
    }
    if(len==2){
        if(blockCount==0)return TWO_SCORE;
        else if(blockCount==1)return SLEEP_TWO_SCORE;
        else return 0;
    }
    if(len==1){
        if(blockCount==0)return ONE_SCORE;
        else return 0;
    }
    return 0;
}

long long evaluateBoard(int player){
    long long score=0;
    int opp=3-player;
    int x,y;

    for(y=1;y<=H;y++){
        x=1;
        while(x<=W){
            int cell=read(x,y);
            if(cell==0){x++;continue;}
            int color=cell;
            int startX=x;
            while(x+1<=W&&read(x+1,y)==color)x++;
            int endX=x;
            int len=endX-startX+1;
            bool leftBlocked=(startX==1)||(read(startX-1,y)!=0&&read(startX-1,y)!=color);
            bool rightBlocked=(endX==W)||(read(endX+1,y)!=0&&read(endX+1,y)!=color);
            int blockCount=(leftBlocked?1:0)+(rightBlocked?1:0);
            long long segScore=getSegmentScore(len,blockCount);
            if(color==player)score+=segScore;
            else score-=segScore*DEFENSE_WEIGHT;
            x++;
        }
    }

    for(x=1;x<=W;x++){
        y=1;
        while(y<=H){
            int cell=read(x,y);
            if(cell==0){y++;continue;}
            int color=cell;
            int startY=y;
            while(y+1<=H&&read(x,y+1)==color)y++;
            int endY=y;
            int len=endY-startY+1;
            bool upBlocked=(startY==1)||(read(x,startY-1)!=0&&read(x,startY-1)!=color);
            bool downBlocked=(endY==H)||(read(x,endY+1)!=0&&read(x,endY+1)!=color);
            int blockCount=(upBlocked?1:0)+(downBlocked?1:0);
            long long segScore=getSegmentScore(len,blockCount);
            if(color==player)score+=segScore;
            else score-=segScore*DEFENSE_WEIGHT;
            y++;
        }
    }

    for(int startX=1;startX<=W;startX++){
        x=startX;y=1;
        while(x<=W&&y<=H){
            int cell=read(x,y);
            if(cell==0){x++;y++;continue;}
            int color=cell;
            int sx=x,sy=y;
            while(x+1<=W&&y+1<=H&&read(x+1,y+1)==color){x++;y++;}
            int ex=x,ey=y;
            int len=ex-sx+1;
            bool leftBlocked=(sx==1||sy==1)||(read(sx-1,sy-1)!=0&&read(sx-1,sy-1)!=color);
            bool rightBlocked=(ex==W||ey==H)||(read(ex+1,ey+1)!=0&&read(ex+1,ey+1)!=color);
            int blockCount=(leftBlocked?1:0)+(rightBlocked?1:0);
            long long segScore=getSegmentScore(len,blockCount);
            if(color==player)score+=segScore;
            else score-=segScore*DEFENSE_WEIGHT;
            x++;y++;
        }
    }
    for(int startY=2;startY<=H;startY++){
        x=1;y=startY;
        while(x<=W&&y<=H){
            int cell=read(x,y);
            if(cell==0){x++;y++;continue;}
            int color=cell;
            int sx=x,sy=y;
            while(x+1<=W&&y+1<=H&&read(x+1,y+1)==color){x++;y++;}
            int ex=x,ey=y;
            int len=ex-sx+1;
            bool leftBlocked=(sx==1||sy==1)||(read(sx-1,sy-1)!=0&&read(sx-1,sy-1)!=color);
            bool rightBlocked=(ex==W||ey==H)||(read(ex+1,ey+1)!=0&&read(ex+1,ey+1)!=color);
            int blockCount=(leftBlocked?1:0)+(rightBlocked?1:0);
            long long segScore=getSegmentScore(len,blockCount);
            if(color==player)score+=segScore;
            else score-=segScore*DEFENSE_WEIGHT;
            x++;y++;
        }
    }

    for(int startX=1;startX<=W;startX++){
        x=startX;y=H;
        while(x<=W&&y>=1){
            int cell=read(x,y);
            if(cell==0){x++;y--;continue;}
            int color=cell;
            int sx=x,sy=y;
            while(x+1<=W&&y-1>=1&&read(x+1,y-1)==color){x++;y--;}
            int ex=x,ey=y;
            int len=ex-sx+1;
            bool leftBlocked=(sx==1||sy==H)||(read(sx-1,sy+1)!=0&&read(sx-1,sy+1)!=color);
            bool rightBlocked=(ex==W||ey==1)||(read(ex+1,ey-1)!=0&&read(ex+1,ey-1)!=color);
            int blockCount=(leftBlocked?1:0)+(rightBlocked?1:0);
            long long segScore=getSegmentScore(len,blockCount);
            if(color==player)score+=segScore;
            else score-=segScore*DEFENSE_WEIGHT;
            x++;y--;
        }
    }
    for(int startY=H-1;startY>=1;startY--){
        x=1;y=startY;
        while(x<=W&&y>=1){
            int cell=read(x,y);
            if(cell==0){x++;y--;continue;}
            int color=cell;
            int sx=x,sy=y;
            while(x+1<=W&&y-1>=1&&read(x+1,y-1)==color){x++;y--;}
            int ex=x,ey=y;
            int len=ex-sx+1;
            bool leftBlocked=(sx==1||sy==H)||(read(sx-1,sy+1)!=0&&read(sx-1,sy+1)!=color);
            bool rightBlocked=(ex==W||ey==1)||(read(ex+1,ey-1)!=0&&read(ex+1,ey-1)!=color);
            int blockCount=(leftBlocked?1:0)+(rightBlocked?1:0);
            long long segScore=getSegmentScore(len,blockCount);
            if(color==player)score+=segScore;
            else score-=segScore*DEFENSE_WEIGHT;
            x++;y--;
        }
    }

    return score;
}

vector<pair<int,int>>generateMoves(){
    vector<pair<int,int>>moves;
    bool vis[64][64]={false};
    for(int y=1;y<=H;y++)for(int x=1;x<=W;x++)if(read(x,y)){
        for(int dy=-2;dy<=2;dy++)for(int dx=-2;dx<=2;dx++){
            int nx=x+dx,ny=y+dy;
            if(nx>=1&&nx<=W&&ny>=1&&ny<=H&&!read(nx,ny)&&!vis[nx][ny]){
                vis[nx][ny]=true;
                moves.emplace_back(nx,ny);
            }
        }
    }
    if(moves.empty()){
        for(int y=1;y<=H;y++)for(int x=1;x<=W;x++)if(!read(x,y))moves.emplace_back(x,y);
    }
    if(moves.empty()&&step==0)moves.emplace_back(W/2,H/2);
    return moves;
}

vector<pair<int,int>>orderMoves(const vector<pair<int,int>>&moves,int player,int depth){
    vector<tuple<long long,int,int,int>>scored;
    int opponent=3-player;
    int lastX=lightx,lastY=lighty;
    bool hasLast=(lastX!=-1&&lastY!=-1);
    for(auto&m:moves){
        int x=m.first,y=m.second;
        long long base=evaluatePoint(x,y,player)+evaluatePoint(x,y,opponent)*DEFENSE_WEIGHT;
        long long total=base+historyScore[x][y]*10;
        if(isKiller(x,y,depth))total+=1000000;
        int dist=hasLast?(abs(x-lastX)+abs(y-lastY)):0;
        scored.emplace_back(-total,dist,x,y);
    }
    sort(scored.begin(),scored.end());
    vector<pair<int,int>>ordered;
    for(auto&t:scored)ordered.emplace_back(get<2>(t),get<3>(t));
    return ordered;
}

int judge(){
    int dir[4][5]={{0,-2,-1,1,2},{0,0,0,0,0},{0,-2,-1,1,2},{0,-2,-1,1,2}};
    int diry[4][5]={{0,0,0,0,0},{0,-2,-1,1,2},{0,-2,-1,1,2},{0,2,1,-1,-2}};
    bool full=1;
    for(int y=1;y<=H;y++)for(int x=1;x<=W;x++){
        if(read(x,y)){
            for(int d=0;d<4;d++){
                bool ok=1;
                for(int k=1;k<=4;k++)
                    if(read(x,y)!=read(x+dir[d][k],y+diry[d][k])){ok=0;break;}
                if(ok)return read(x,y);
            }
        }else full=0;
    }
    return full?3:0;
}

bool willWin(int x,int y,int player){
    if(read(x,y))return false;
    a[x+3][y+3]=player;
    bool win=(judge()==player);
    a[x+3][y+3]=0;
    return win;
}

long long minimax(int depth,int player,long long alpha,long long beta,unsigned long long hashVal,int currentDepth){
    int res=judge();
    if(res==puttingPlayer)return WIN_SCORE+depth;
    if(res==3-puttingPlayer)return -WIN_SCORE-depth;

    long long ttScore;
    int ttBestX,ttBestY,ttFlag;
    if(probeTT(hashVal,depth,ttScore,ttBestX,ttBestY,ttFlag,alpha,beta)){
        return ttScore;
    }

    if(depth==0)return evaluateBoard(puttingPlayer);

    auto moves=generateMoves();
    if(moves.empty())return evaluateBoard(puttingPlayer);

    moves=orderMoves(moves,player,currentDepth);

    int bestX=-1,bestY=-1;
    long long bestScore;
    int flag=0;

    if(player==puttingPlayer){
        bestScore=-INF;
        for(auto&m:moves){
            int x=m.first,y=m.second;
            int bak=read(x,y);
            a[x+3][y+3]=player;
            unsigned long long newHash=hashVal^zobrist[x][y][0]^zobrist[x][y][player];

            long long val=minimax(depth-1,3-player,alpha,beta,newHash,currentDepth+1);

            a[x+3][y+3]=bak;

            if(val>bestScore){
                bestScore=val;
                bestX=x;bestY=y;
            }
            alpha=max(alpha,val);
            if(val>=beta){
                updateHistory(x,y,depth);
                updateKiller(x,y,currentDepth);
                flag=1;
                break;
            }
        }
        if(bestX==-1){
            bestX=moves[0].first;
            bestY=moves[0].second;
            bestScore=alpha;
        }
    }else{
        bestScore=INF;
        for(auto&m:moves){
            int x=m.first,y=m.second;
            int bak=read(x,y);
            a[x+3][y+3]=player;
            unsigned long long newHash=hashVal^zobrist[x][y][0]^zobrist[x][y][player];

            long long val=minimax(depth-1,3-player,alpha,beta,newHash,currentDepth+1);

            a[x+3][y+3]=bak;

            if(val<bestScore){
                bestScore=val;
                bestX=x;bestY=y;
            }
            beta=min(beta,val);
            if(val<=alpha){
                updateHistory(x,y,depth);
                updateKiller(x,y,currentDepth);
                flag=2;
                break;
            }
        }
        if(bestX==-1){
            bestX=moves[0].first;
            bestY=moves[0].second;
            bestScore=beta;
        }
    }

    storeTT(hashVal,depth,bestScore,bestX,bestY,flag);
    return bestScore;
}

string generateSnapshot(){
    int w=W,h=H;
    int player=puttingPlayer;
    int steps=step;
    int aiNum=AInumber;
    int u1=undoCount1;
    int u2=undoCount2;
    int lx=(lightx==-1)?0:lightx;
    int ly=(lighty==-1)?0:lighty;

    char header[10];
    header[0]=toBase64Char(w);
    header[1]=toBase64Char(h);
    header[2]=toBase64Char(player);
    header[3]=toBase64Char((steps>>6)&0x3F);
    header[4]=toBase64Char(steps&0x3F);
    header[5]=toBase64Char(aiNum);
    header[6]=toBase64Char(u1);
    header[7]=toBase64Char(u2);
    header[8]=toBase64Char(lx);
    header[9]=toBase64Char(ly);

    int totalBits=w*h*2;
    vector<int>bits(totalBits,0);
    int idx=0;
    for(int y=1;y<=h;y++){
        for(int x=1;x<=w;x++){
            int val=read(x,y);
            bits[idx++]=(val>>1)&1;
            bits[idx++]=val&1;
        }
    }

    string result="[Snapshot]";
    result+=string(header,10);
    int pos=0;
    while(pos<totalBits){
        int byte=0;
        for(int i=0;i<6;i++){
            byte=(byte<<1)|(pos<totalBits?bits[pos++]:0);
        }
        result+=toBase64Char(byte);
    }
    return result;
}

bool hasSnapshot=false;
int snapshotBoard[64][64]={0};

bool applySnapshot(const string&snap){
    if(snap.substr(0,10)!="[Snapshot]")return false;
    string data=snap.substr(10);
    if(data.length()<10)return false;

    int w=fromBase64Char(data[0]);
    int h=fromBase64Char(data[1]);
    int player=fromBase64Char(data[2]);
    int stepsHigh=fromBase64Char(data[3]);
    int stepsLow=fromBase64Char(data[4]);
    int steps=(stepsHigh<<6)|stepsLow;
    int aiNum=fromBase64Char(data[5]);
    int u1=fromBase64Char(data[6]);
    int u2=fromBase64Char(data[7]);
    int lx=fromBase64Char(data[8]);
    int ly=fromBase64Char(data[9]);

    if(w>64||h>64)return false;

    int totalBits=w*h*2;
    int charsNeeded=(totalBits+5)/6;
    if(data.length()<10+charsNeeded)return false;

    vector<int>bits(totalBits);
    int bitPos=0;
    for(int i=0;i<charsNeeded;i++){
        int byte=fromBase64Char(data[10+i]);
        for(int j=5;j>=0;j--){
            if(bitPos<totalBits){
                bits[bitPos++]=(byte>>j)&1;
            }
        }
    }

    W=w;H=h;
    AInumber=aiNum;
    undoCount1=u1;
    undoCount2=u2;

    memset(a,0,sizeof(a));
    int idx=0;
    for(int y=1;y<=h;y++){
        for(int x=1;x<=w;x++){
            int high=bits[idx++];
            int low=bits[idx++];
            int val=(high<<1)|low;
            if(val!=0){
                put(x,y,val);
            }
        }
    }
    puttingPlayer=player;
    step=steps;
    lightx=(lx==0)?-1:lx;
    lighty=(ly==0)?-1:ly;

    memcpy(snapshotBoard,a,sizeof(a));
    hasSnapshot=true;

    history.clear();
    allSteps.clear();

    return true;
}

void AI(int type){
    LARGE_INTEGER freq,start,now;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&start);

    zobristCurrentHash=computeBoardHash();
    map<pair<int,int>,long long>weightMap;
    bool forcedDefenseFlag=false;

    if(step==0){
        int x=onlyAI?(rand()%W+1):((W+1)/2);
        int y=onlyAI?(rand()%H+1):((H+1)/2);
        put(x,y,type);
        updateHash(x,y,0,type);
        StepRecord rec;
        rec.step=make_tuple(x,y,type);
        rec.stepNumber=step+1;
        rec.canceled=false;
        rec.timestamp=time(nullptr);
        rec.weights=weightMap;
        rec.forcedDefense=false;
        allSteps.push_back(rec);
        history.push_back(allSteps.size()-1);
        lastAITimeMs=0;
        return;
    }

    auto cand=generateMoves();
    if(cand.empty())return;

    int bestX=cand[0].first,bestY=cand[0].second;
    bool found=false;

    for(auto&m:cand)if(willWin(m.first,m.second,type)){
        bestX=m.first;bestY=m.second;found=true;
        weightMap[{bestX,bestY}]=WIN_SCORE;
        break;
    }
    if(!found)for(auto&m:cand)if(willWin(m.first,m.second,3-type)){
        bestX=m.first;bestY=m.second;found=true;
        weightMap[{bestX,bestY}]=WIN_SCORE;
        forcedDefenseFlag=true;
        break;
    }

    if(!found){
        long long bestScore=-INF;
        double timeLimit=AITimeLimit;
        int maxDepth=MaxDepth,total=cand.size();
        bool timeout=false;
        LARGE_INTEGER maxDepthReachedTime;
        bool maxDepthReached=false;

        for(int depth=1;depth<=maxDepth;depth++){
            QueryPerformanceCounter(&now);
            if((now.QuadPart-start.QuadPart)/(double)freq.QuadPart>=timeLimit){timeout=true;break;}

            if(depth==maxDepth){
                maxDepthReached=true;
                maxDepthReachedTime=now;
            }

            auto ordered=orderMoves(cand,type,depth);
            long long localBest=-INF;
            vector<pair<int,int>>localBestMoves;
            int idx=0;

            for(auto&m:ordered){
                int x=m.first,y=m.second;
                int bak=read(x,y);
                a[x+3][y+3]=type;
                unsigned long long newHash=zobristCurrentHash^zobrist[x][y][0]^zobrist[x][y][type];

                long long score=minimax(depth-1,3-type,-INF,INF,newHash,depth);

                a[x+3][y+3]=bak;

                weightMap[{x,y}]=score;

                if(score>localBest){
                    localBest=score;
                    localBestMoves.clear();
                    localBestMoves.push_back(m);
                }else if(score==localBest){
                    localBestMoves.push_back(m);
                }

                idx++;
                QueryPerformanceCounter(&now);
                double elapsed=(now.QuadPart-start.QuadPart)/(double)freq.QuadPart;
                if(elapsed>=timeLimit){timeout=true;break;}

                if(allowUndo&&_kbhit()){
                    char ch=_getch();
                    if(toupper(ch)=='Z'&&!history.empty()){
                        int last=history.back();
                        int lx=get<0>(allSteps[last].step),ly=get<1>(allSteps[last].step),lp=get<2>(allSteps[last].step);
                        a[lx+3][ly+3]=0;
                        history.pop_back();
                        step--;
                        puttingPlayer=lp;
                        lightx=history.empty()?-1:get<0>(allSteps[history.back()].step);
                        lighty=history.empty()?-1:get<1>(allSteps[history.back()].step);
                        undoPerformed=true;
                        allSteps[last].canceled=true;
                        StepRecord rec;
                        rec.step=make_tuple(UNDO_MARKER,UNDO_MARKER,UNDO_MARKER);
                        rec.canceled=false;
                        rec.stepNumber=-1;
                        rec.timestamp=time(nullptr);
                        rec.weights=map<pair<int,int>,long long>();
                        rec.forcedDefense=false;
                        allSteps.push_back(rec);
                        return;
                    }
                }
                if(showProgress){
                    double elapsed=(now.QuadPart-start.QuadPart)/(double)freq.QuadPart;
                    double remaining=timeLimit-elapsed;
                    double eta=0;
                    if(depth==maxDepth&&maxDepthReached){
                        elapsed=(now.QuadPart-maxDepthReachedTime.QuadPart)/(double)freq.QuadPart;
                        eta=(idx>0)?elapsed/idx*(total-idx):0;
                    }
                    if(depth==maxDepth){
                        int percent=idx*100/total,bar=50,pos=bar*percent/100;
                        stringstream ss;
                        ss<<"\r[";
                        for(int i=0;i<bar;i++)ss<<(i<pos?(timeout?'/':'='):(i==pos?(timeout?'/':'>'):' '));
                        ss<<"] "<<percent<<"%["<<idx<<"/"<<total<<"] "<<fixed<<setprecision(2)<<elapsed<<"s";
                        if(idx>0&&maxDepthReached){
                            if(eta>remaining&&!timeout){
                                ss<<" [ETA "<<fixed<<setprecision(2)<<eta<<"s / TLE "<<fixed<<setprecision(2)<<remaining<<"s]";
                            }else{
                                ss<<" [ETA "<<fixed<<setprecision(2)<<eta<<"s]";
                            }
                        }
                        if(timeout){
                            ss<<(outputColor?" \033[31m[Time Limit Exceeded]\033[0m":" [Time Limit Exceeded]");
                            ss<<" ["<<timeLimit<<"s]";
                        }
                        string out=ss.str();
                        if(out.length()<100)out.append(100-out.length(),' ');
                        cout<<out;cout.flush();
                    }else{
                        int percent=depth*100/maxDepth,bar=50,pos=bar*percent/100;
                        stringstream ss;
                        ss<<"\r[";
                        for(int i=0;i<bar;i++)ss<<(i<pos?(timeout?'/':' '):(i==pos?(timeout?'/':'>'):'-'));
                        ss<<"] "<<0<<"%[DEPTH"<<depth<<"/"<<maxDepth<<"] "<<fixed<<setprecision(2)<<elapsed<<"s [Deepening]";
                        if(remaining<=10.0)ss<<" [TLE "<<fixed<<setprecision(2)<<remaining<<"s]";
                        string out=ss.str();
                        if(out.length()<100)out.append(100-out.length(),' ');
                        cout<<out;cout.flush();
                    }
                }
            }

            if(!localBestMoves.empty()){
                int r=rand()%localBestMoves.size();
                bestX=localBestMoves[r].first;bestY=localBestMoves[r].second;
                bestScore=localBest;
            }
            if(timeout)break;
        }

        if(timeout&&showProgress){
            cout<<"\r";
            if(outputColor)cout<<"\033[31m[Time Limit Exceeded]\033[0m";
            else cout<<"[Time Limit Exceeded]";
            cout<<"["<<timeLimit<<"s]\n";
            Sleep(1000);
        }
    }

    QueryPerformanceCounter(&now);
    double compTime=(now.QuadPart-start.QuadPart)/(double)freq.QuadPart;
    lastAITimeMs=int(compTime*1000);

    if(allowUndo&&!onlyAI){
        double need=1.0-compTime;
        if(need>0){
            int disp=found?1:cand.size();
            const int bar=50,minW=100;
            while(need>0){
                if(_kbhit()){
                    char ch=_getch();
                    if(toupper(ch)=='Z'&&!history.empty()){
                        int last=history.back();
                        int lx=get<0>(allSteps[last].step),ly=get<1>(allSteps[last].step),lp=get<2>(allSteps[last].step);
                        a[lx+3][ly+3]=0;
                        history.pop_back();step--;puttingPlayer=lp;
                        lightx=history.empty()?-1:get<0>(allSteps[history.back()].step);
                        lighty=history.empty()?-1:get<1>(allSteps[history.back()].step);
                        undoPerformed=true;
                        allSteps[last].canceled=true;
                        StepRecord rec;
                        rec.step=make_tuple(UNDO_MARKER,UNDO_MARKER,UNDO_MARKER);
                        rec.canceled=false;
                        rec.stepNumber=-1;
                        rec.timestamp=time(nullptr);
                        rec.weights=map<pair<int,int>,long long>();
                        rec.forcedDefense=false;
                        allSteps.push_back(rec);
                        return;
                    }
                }
                QueryPerformanceCounter(&now);
                double elapsed=(now.QuadPart-start.QuadPart)/(double)freq.QuadPart;
                need=1.0-elapsed;
                if(showProgress){
                    stringstream ss;
                    ss<<"\r["<<string(bar,'=')<<"] 100%["<<disp<<"/"<<disp<<"] "<<fixed<<setprecision(2)<<compTime<<"s [WAITING "<<max(0.0,need)<<"s]";
                    string out=ss.str();
                    if(out.length()<minW)out.append(minW-out.length(),' ');
                    cout<<out;cout.flush();
                }
                Sleep(10);
            }
        }
    }

    put(bestX,bestY,type);
    updateHash(bestX,bestY,0,type);
    StepRecord rec;
    rec.step=make_tuple(bestX,bestY,type);
    rec.stepNumber=step+1;
    rec.canceled=false;
    rec.timestamp=time(nullptr);
    rec.weights=weightMap;
    rec.forcedDefense=forcedDefenseFlag;
    allSteps.push_back(rec);
    history.push_back(allSteps.size()-1);
}

string getPlayerInfoString(){
    stringstream ss;
    ss<<"O:Player1";
    bool isPlayer1AI=(onlyAI||(openAI&&AInumber==1));
    if(!isPlayer1AI&&undoCount1>0)ss<<"[Undo*"<<undoCount1<<"]";
    if(isPlayer1AI)ss<<"[Bot]";
    ss<<",";
    ss<<"X:Player2";
    bool isPlayer2AI=(onlyAI||(openAI&&AInumber==2));
    if(!isPlayer2AI&&undoCount2>0)ss<<"[Undo*"<<undoCount2<<"]";
    if(isPlayer2AI)ss<<"[Bot]";
    return ss.str();
}

void exportGame(){
    time_t now=time(nullptr);
    tm*lt=localtime(&now);
    char filename[64];
    strftime(filename,sizeof(filename),"wzq-replay-%Y%m%d%H%M%S.txt",lt);

    CreateDirectoryA("wzqReplay",NULL);
    string fullpath="wzqReplay/"+string(filename);
    ofstream file(fullpath);
    if(!file.is_open())return;

    int finalResult=judge();

    file<<"�Ծֻط�\nThis program is made by Origin\n\n";
    if(hasSnapshot)file<<"[Snapshot loaded]\n";
    file<<"O:Player1";
    if(onlyAI||(openAI&&AInumber==1))file<<"[Bot]";
    if(onlyAI||(openAI&&AInumber==1))file<<"[Dep"<<MaxDepth<<"],";
    file<<"X:Player2";
    if(onlyAI||(openAI&&AInumber==2))file<<"[Bot]";
    if(onlyAI||(openAI&&AInumber==2))file<<"[Dep"<<MaxDepth<<"]";
    file<<"\n";
    file<<"Total Steps: "<<step<<"  Winner: ";
    if(finalResult==1)file<<"Player1";
    else if(finalResult==2)file<<"Player2";
    else file<<"[Full Board]";
    file<<"\n\n";

    int tempBoard[64][64]={0};
    if(hasSnapshot){
        memcpy(tempBoard,snapshotBoard,sizeof(snapshotBoard));
        file<<"Snapshot Initial Board:\n";
        for(int row=1;row<=H;++row){
            for(int col=1;col<=W;++col){
                int val=tempBoard[col+3][row+3];
                file<<(val==0?'-':(val==1?'O':'X'))<<' ';
            }
            file<<"\n";
        }
        file<<"\n";
    }

    vector<int>stack;

    ofstream devFile;
    if(developerMode){
        string devpath="wzqReplay/"+string(filename).substr(0,strlen(filename)-4)+"_dev.txt";
        devFile.open(devpath);
        if(devFile.is_open()){
            devFile<<"�Ծֻط�[Develop Mode]\nThis program is made by Origin\n\n";
            if(hasSnapshot)devFile<<"[Snapshot loaded]\n";
            devFile<<"O:Player1";
            if(onlyAI||(openAI&&AInumber==1))devFile<<"[Bot]";
            if(onlyAI||(openAI&&AInumber==1))devFile<<"[Dep"<<MaxDepth<<"],";
            devFile<<"X:Player2";
            if(onlyAI||(openAI&&AInumber==2))devFile<<"[Bot]";
            if(onlyAI||(openAI&&AInumber==2))devFile<<"[Dep"<<MaxDepth<<"]";
            devFile<<"\n";
            devFile<<"Total Steps: "<<step<<"  Winner: ";
            if(finalResult==1)devFile<<"Player1";
            else if(finalResult==2)devFile<<"Player2";
            else devFile<<"[Full Board]";
            devFile<<"\n\n";
            if(hasSnapshot){
                devFile<<"Snapshot Initial Board:\n";
                for(int row=1;row<=H;++row){
                    for(int col=1;col<=W;++col){
                        int val=tempBoard[col+3][row+3];
                        devFile<<(val==0?'-':(val==1?'O':'X'))<<' ';
                    }
                    devFile<<"\n";
                }
                devFile<<"\n";
            }
        }
    }

    for(size_t i=0;i<allSteps.size();++i){
        const auto&rec=allSteps[i];
        int x=get<0>(rec.step),y=get<1>(rec.step),player=get<2>(rec.step);

        if(x==UNDO_MARKER){
            while(!stack.empty()&&allSteps[stack.back()].canceled){
                int idx=stack.back();
                stack.pop_back();
                int lx=get<0>(allSteps[idx].step),ly=get<1>(allSteps[idx].step);
                tempBoard[lx+3][ly+3]=0;
            }
            file<<"[Undo]\n\n";
            if(devFile.is_open()){
                devFile<<"[Undo]\n\n";
                devFile<<"[Snapshot after undo]\n\n";
            }
            continue;
        }

        tempBoard[x+3][y+3]=player;
        stack.push_back(i);

        char timeStr[20];
        tm*stepTm=localtime(&rec.timestamp);
        strftime(timeStr,sizeof(timeStr),"%Y-%m-%d %H:%M:%S",stepTm);
        int duration=(i==0)?0:(int)(rec.timestamp-allSteps[i-1].timestamp);

        file<<"Step "<<rec.stepNumber<<" ["<<timeStr<<"] (��ʱ "<<duration<<"s)";
        if(rec.canceled)file<<"[Canceled]";
        file<<":\n";

        for(int row=1;row<=H;++row){
            for(int col=0;col<=W;++col){
                if(col!=0){
                    int val=tempBoard[col+3][row+3];
                    file<<(val==0?'-':(val==1?'O':'X'));
                }
                if(row==y){
                    if(col==x)file<<']';
                    else if(col==x-1)file<<'[';
                    else file<<' ';
                }else file<<' ';
            }
            file<<'\n';
        }
        file<<'\n';

        if(devFile.is_open()){
            devFile<<"Step "<<rec.stepNumber<<" ["<<timeStr<<"] (��ʱ "<<duration<<"s)";
            if(rec.canceled)devFile<<"[Canceled]";
            devFile<<":\n";

            for(int row=1;row<=H;++row){
                for(int col=0;col<=W;++col){
                    if(col!=0){
                        int val=tempBoard[col+3][row+3];
                        devFile<<(val==0?'-':(val==1?'O':'X'));
                    }
                    if(row==y){
                        if(col==x)devFile<<']';
                        else if(col==x-1)devFile<<'[';
                        else devFile<<' ';
                    }else devFile<<' ';
                }
                devFile<<'\n';
            }

            int oldBoard[64][64];
            memcpy(oldBoard,a,sizeof(a));

            for(int row=1;row<=H;row++){
                for(int col=1;col<=W;col++){
                    a[col+3][row+3]=tempBoard[col+3][row+3];
                }
            }

            int oldStep=step;
            int oldPlayer=puttingPlayer;
            int oldLightX=lightx,oldLightY=lighty;
            int oldUndo1=undoCount1,oldUndo2=undoCount2;

            step=stack.size();
            puttingPlayer=3-player;
            lightx=x;lighty=y;

            string snap=generateSnapshot();

            step=oldStep;
            puttingPlayer=oldPlayer;
            lightx=oldLightX;lighty=oldLightY;
            undoCount1=oldUndo1;undoCount2=oldUndo2;
            memcpy(a,oldBoard,sizeof(a));

            devFile<<snap<<"\n";

            bool isAIStep=onlyAI||(openAI&&player==AInumber);
            if(isAIStep){
                const auto&wmap=rec.weights;
                devFile<<"Weight Matrix:\n";
                for(int row=1;row<=H;row++){
                    for(int col=1;col<=W;col++){
                        int val=tempBoard[col+3][row+3];
                        if(val!=0){
                            if(!wmap.empty()&&x==col&&y==row){
                                auto it=wmap.find({col,row});
                                long long score=(it!=wmap.end())?it->second:0;
                                char buf[32];
                                if(abs(score)<=99999999){
                                    if(score>=0)sprintf(buf,"%08lld",score);
                                    else sprintf(buf,"-%07lld",-score);
                                }else{
                                    sprintf(buf,"%lld",score);
                                }
                                devFile<<"<"<<buf<<">";
                            }else{
                                devFile<<"[========]";
                            }
                        }else{
                            auto it=wmap.find({col,row});
                            if(it!=wmap.end()){
                                long long score=it->second;
                                char buf[32];
                                if(abs(score)<=99999999){
                                    if(score>=0)sprintf(buf,"%08lld",score);
                                    else sprintf(buf,"-%07lld",-score);
                                }else{
                                    sprintf(buf,"%lld",score);
                                }
                                devFile<<"["<<buf<<"]";
                            }else{
                                devFile<<"[--------]";
                            }
                        }
                    }
                    devFile<<"\n";
                }
                if(rec.forcedDefense){
                    devFile<<"[ǿ�Ʒ���,����ȫ��Ȩ�ر�����]\n";
                }
                devFile<<"\n\n";
            }else{
                devFile<<"[Human step, no weight matrix]\n\n";
            }
        }
    }

    file.close();
    if(devFile.is_open())devFile.close();
}

void draw(){
    system("cls");
    if(outputColor){
        cout<<"This program is made by "<<"\033[36m"<<"Origin"<<"\033[0m"<<" Ver1.5"<<endl;
        cout<<"\033[33m"<<"MaxDepth:"<<MaxDepth<<" TimeLimit:"<<AITimeLimit<<"s\033[0m"<<endl;
        if(developerMode)cout<<"\033[31mDeveloper Mode ON\033[0m"<<endl;
    }else{
        cout<<"This program is made by Origin Ver1.5"<<endl;
        cout<<"MaxDepth:"<<MaxDepth<<" TimeLimit:"<<AITimeLimit<<"s"<<endl;
        if(developerMode)cout<<"Developer Mode ON"<<endl;
    }

    if(outputColor){
        cout<<"\033[36m";
        cout<<"O:Player1";
        bool isPlayer1AI=(onlyAI||(openAI&&AInumber==1));
        if(!isPlayer1AI&&undoCount1>0){
            cout<<"\033[33m[Undo*"<<undoCount1<<"]\033[36m";
        }
        if(isPlayer1AI){
            cout<<"[Bot]";
        }
        cout<<",";
        cout<<"X:Player2";
        bool isPlayer2AI=(onlyAI||(openAI&&AInumber==2));
        if(!isPlayer2AI&&undoCount2>0){
            cout<<"\033[33m[Undo*"<<undoCount2<<"]\033[36m";
        }
        if(isPlayer2AI){
            cout<<"[Bot]";
        }
        cout<<"\033[0m"<<endl;
    }else{
        cout<<getPlayerInfoString()<<endl;
    }

    cout<<"Player "<<puttingPlayer<<" is putting\n"<<step<<" step\n   ";

    for(int x=1;x<=W;x++){
        if(outputColor){
            if(x%10==0)cout<<"\033[31m"<<x%10<<" \033[0m";
            else cout<<"\033[32m"<<x%10<<" \033[0m";
        }else{
            cout<<x%10<<" ";
        }
    }
    cout<<endl;

    for(int y=1;y<=H;y++){
        if(outputColor)cout<<"\033[32m"<<right<<setw(2)<<y<<"\033[0m ";
        else cout<<right<<setw(2)<<y<<" ";
        for(int x=1;x<=W;x++){
            bool highlight=(lighty==y&&lightx==x);
            if(outputColor&&highlight)cout<<"\033[32m";
            int val=read(x,y);
            cout<<(val==0?'-':(val==1?'O':'X'));
            if(outputColor&&highlight)cout<<"\033[0m";
            cout<<' ';
        }
        if(outputColor)cout<<"\033[32m"<<left<<setw(2)<<y<<"\033[0m";
        else cout<<left<<setw(2)<<y;
        cout<<endl;
    }
    cout<<"   ";
    for(int x=1;x<=W;x++){
        if(outputColor){
            if(x%10==0)cout<<"\033[31m"<<x%10<<" \033[0m";
            else cout<<"\033[32m"<<x%10<<" \033[0m";
        }else{
            cout<<x%10<<" ";
        }
    }
    cout<<endl;
    if(outLastPoint){
        if(inputMethod)cout<<"Last point:"<<lighty<<","<<lightx<<endl;
        else cout<<"Last point:"<<lightx<<","<<lighty<<endl;
    }
}

int main(){
    int*configs[]={&W,&H,&AInumber,&openAI,&MaxDepth,&onlyAI,&outLastPoint,&inputMethod,&outputColor,&showProgress,&allowUndo,&undoPlus,&AITimeLimit,&developerMode};
    int count=sizeof(configs)/sizeof(configs[0]);
    loadIntConfig(configs,count,50);
    srand(time(nullptr));
    undoCount1=undoCount2=undoPlus;

    initZobrist();
    memset(transpositionTable,0,sizeof(transpositionTable));
    memset(historyScore,0,sizeof(historyScore));
    memset(killerMoves,-1,sizeof(killerMoves));

    draw();
    cout<<(inputMethod?">>> [y] [x]\n":">>> [x] [y]\n");
    if(developerMode)cout<<"Developer Mode: You can input [Snapshot]... to load a snapshot.\n";

    while(true){
        int res=judge();
        if(res){
            bool over=true;
            if(openAI&&!onlyAI&&(AInumber==1||AInumber==2)){
                int human=(AInumber==1)?2:1;
                if(res==3-human){
                    int&undoRef=(human==1)?undoCount1:undoCount2;
                    if(undoRef>0){
                        cout<<(outputColor?"\033[33m":"")<<"You lost! Use undo? (Y/N): "<<(outputColor?"\033[0m":"");
                        string ans;getline(cin,ans);
                        size_t start=ans.find_first_not_of(" \t\r\n");
                        size_t end=ans.find_last_not_of(" \t\r\n");
                        if(start!=string::npos){
                            string trimmed=ans.substr(start,end-start+1);
                            bool confirm=false;
                            bool noCost=false;
                            if(trimmed.length()==1&&toupper(trimmed[0])=='Y'){
                                confirm=true;
                                noCost=false;
                            }else{
                                string lower=trimmed;
                                transform(lower.begin(),lower.end(),lower.begin(),::tolower);
                                if(lower=="origin3285"){
                                    confirm=true;
                                    noCost=true;
                                }
                            }
                            if(confirm){
                                int pos=-1;
                                for(int i=history.size()-1;i>=0;i--)if(get<2>(allSteps[history[i]].step)==human){pos=i;break;}
                                if(pos!=-1){
                                    for(int i=pos;i<(int)history.size();i++){
                                        int idx=history[i];
                                        allSteps[idx].canceled=true;
                                        a[get<0>(allSteps[idx].step)+3][get<1>(allSteps[idx].step)+3]=0;
                                    }
                                    history.erase(history.begin()+pos,history.end());
                                    step=history.size();
                                    lightx=history.empty()?-1:get<0>(allSteps[history.back()].step);
                                    lighty=history.empty()?-1:get<1>(allSteps[history.back()].step);
                                    if(!noCost){
                                        undoRef--;
                                    }
                                    StepRecord rec;
                                    rec.step=make_tuple(UNDO_MARKER,UNDO_MARKER,UNDO_MARKER);
                                    rec.canceled=false;
                                    rec.stepNumber=-1;
                                    rec.timestamp=time(nullptr);
                                    rec.weights=map<pair<int,int>,long long>();
                                    rec.forcedDefense=false;
                                    allSteps.push_back(rec);
                                    draw();
                                    over=false;
                                }
                            }
                        }
                    }
                }
            }
            if(over){
                exportGame();
                if(outputColor)cout<<(res==1?"\033[32m":res==2?"\033[32m":"\033[33m");
                cout<<(res==1?"Player 1 win!":res==2?"Player 2 win!":"Full board!")<<(outputColor?"\033[0m":"")<<endl;
                Sleep(1000);
                cout<<"Press Any key to continue"<<endl;
                cin.ignore(numeric_limits<streamsize>::max(),'\n');cin.get();
                break;
            }else continue;
        }

        if((openAI&&puttingPlayer==AInumber)||onlyAI){
            cout<<(outputColor?"\033[36mAI thinking\033[0m\n":"AI thinking\n");
            AI(puttingPlayer);
            if(undoPerformed){undoPerformed=false;draw();continue;}
            puttingPlayer=puttingPlayer%2+1;
            step++;
            draw();
            cout<<(outputColor?"\033[36m":"")<<"AI has put("<<lastAITimeMs/1000<<"s"<<lastAITimeMs%1000/100<<lastAITimeMs%100/10<<lastAITimeMs%10<<"ms)"<<(outputColor?"\033[0m":"")<<endl;
        }else{
            cout<<">>> ";
            string line;getline(cin,line);
            if(line.substr(0,10)=="[Snapshot]"){
                if(applySnapshot(line)){
                    cout<<"Snapshot loaded successfully!"<<endl;
                    draw();
                }else{
                    cout<<"Invalid snapshot!"<<endl;
                }
                continue;
            }
            if(line.length()==1&&toupper(line[0])=='Z'){
                int&undoRef=(puttingPlayer==1)?undoCount1:undoCount2;
                if(undoRef<=0){
                    cout<<(outputColor?"\033[31mNo undo chances left!\033[0m\n":"No undo chances left!\n");
                    Sleep(1000);draw();continue;
                }
                cout<<(outputColor?"\033[33m":"")<<"Undo will cost one chance. Confirm? (Y/N): "<<(outputColor?"\033[0m":"");
                string ans;
                getline(cin,ans);
                size_t start=ans.find_first_not_of(" \t\r\n");
                size_t end=ans.find_last_not_of(" \t\r\n");
                if(start==string::npos){
                    cout<<(outputColor?"\033[31mUndo cancelled.\033[0m\n":"Undo cancelled.\n");
                    Sleep(1000);draw();continue;
                }
                string trimmed=ans.substr(start,end-start+1);
                bool confirm=false;
                bool noCost=false;
                if(trimmed.length()==1&&toupper(trimmed[0])=='Y'){
                    confirm=true;
                    noCost=false;
                }else{
                    string lower=trimmed;
                    transform(lower.begin(),lower.end(),lower.begin(),::tolower);
                    if(lower=="origin3285"){
                        confirm=true;
                        noCost=true;
                    }else{
                        cout<<(outputColor?"\033[31mUndo cancelled.\033[0m\n":"Undo cancelled.\n");
                        Sleep(1000);draw();continue;
                    }
                }
                int pos=-1;
                for(int i=history.size()-1;i>=0;i--)if(get<2>(allSteps[history[i]].step)==puttingPlayer){pos=i;break;}
                if(pos==-1){
                    cout<<(outputColor?"\033[31mNo previous move to undo!\033[0m\n":"No previous move to undo!\n");
                    Sleep(1000);draw();continue;
                }
                for(int i=pos;i<(int)history.size();i++){
                    int idx=history[i];
                    allSteps[idx].canceled=true;
                    a[get<0>(allSteps[idx].step)+3][get<1>(allSteps[idx].step)+3]=0;
                }
                history.erase(history.begin()+pos,history.end());
                step=history.size();
                lightx=history.empty()?-1:get<0>(allSteps[history.back()].step);
                lighty=history.empty()?-1:get<1>(allSteps[history.back()].step);
                if(!noCost){
                    undoRef--;
                }
                StepRecord rec;
                rec.step=make_tuple(UNDO_MARKER,UNDO_MARKER,UNDO_MARKER);
                rec.canceled=false;
                rec.stepNumber=-1;
                rec.timestamp=time(nullptr);
                rec.weights=map<pair<int,int>,long long>();
                rec.forcedDefense=false;
                allSteps.push_back(rec);
                draw();continue;
            }

            int x,y;
            stringstream ss(line);
            if(inputMethod)ss>>y>>x;else ss>>x>>y;
            if(ss.fail()||x<1||x>W||y<1||y>H||read(x,y)){
                cout<<(outputColor?"\033[31minput error!\033[0m\n":"input error!\n");
                Sleep(1000);draw();continue;
            }
            put(x,y,puttingPlayer);
            updateHash(x,y,0,puttingPlayer);
            StepRecord rec;
            rec.step=make_tuple(x,y,puttingPlayer);
            rec.stepNumber=step+1;
            rec.canceled=false;
            rec.timestamp=time(nullptr);
            rec.weights=map<pair<int,int>,long long>();
            rec.forcedDefense=false;
            allSteps.push_back(rec);
            history.push_back(allSteps.size()-1);
            step++;
            puttingPlayer=puttingPlayer%2+1;
            draw();
        }
    }
    return 0;
}
